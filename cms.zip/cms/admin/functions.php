                     <?php



function escape ($string){
    
    global $connection;
    return mysqli_real_escape_string($connection,trim ($string));
    
    
    
}


function count_usersonline(){
    
    if(isset($_GET['onlineusers']))
    {
       global $connection;
if ($connection)
{
     $session = session_id();                        //function to catch id
        $time = time();
        $time_out_in_seconds = 05;                 //amount of time u want the user to be marked offline
        $time_out = $time - $time_out_in_seconds;
        
        $query = "SELECT * FROM users_online WHERE session = '$session' ";
        $send_query = mysqli_query ($connection , $query);
        $count = mysqli_num_rows($send_query);        //counting to see if anyone is online 
        
        
        if($count == NULL)      //means a new user just logged in we will send him a session and time to keep trak on him
        {
            mysqli_query($connection , "INSERT INTO users_online(session,time) VALUES('$session','$time')");
        }
        
        else {          // he's not a new user
            
            mysqli_query($connection , "UPDATE users_online SET time = '$time' WHERE session = '$session'");
        }
        
        $select_users_query = mysqli_query($connection , "SELECT * FROM users_online WHERE time > '$time_out'");
        echo $count_users_online = mysqli_num_rows ($select_users_query);
        } 

        else
        {
            session_start();
            include ("../includes/db.php");
            
            
        $session = session_id();                        //function to catch id
        $time = time();
        $time_out_in_seconds = 05;                 //amount of time u want the user to be marked offline
        $time_out = $time - $time_out_in_seconds;
        
        $query = "SELECT * FROM users_online WHERE session = '$session' ";
        $send_query = mysqli_query ($connection , $query);
        $count = mysqli_num_rows($send_query);        //counting to see if anyone is online 
        
        
        if($count == NULL)      //means a new user just logged in we will send him a session and time to keep trak on him
        {
            mysqli_query($connection , "INSERT INTO users_online(session,time) VALUES('$session','$time')");
        }
        
        else {          // he's not a new user
            
            mysqli_query($connection , "UPDATE users_online SET time = '$time' WHERE session = '$session'");
        }
        
        $select_users_query = mysqli_query($connection , "SELECT * FROM users_online WHERE time > '$time_out'");
        echo $count_users_online = mysqli_num_rows ($select_users_query);
        }
    }
}

count_usersonline();


function insert_categories(){
    
    global $connection;

     if (isset($_POST['submit']))
                         {
                             $cat_title = $_POST['cat_title'];
                             
                             if($cat_title =="" || empty($cat_title)){
                                 echo "this field shouldn't be empty";
                             }
                             else {
                                 $query_insert = "INSERT INTO categories(cat_title) ";
                                 $query_insert.= "VALUES ('{$cat_title}') ";
                                 $create_category_query = mysqli_query ($connection , $query_insert );
                                 
                                 if(!$create_category_query)
                                 {
                                     die("query failed" . mysqli_error($connection));
                                 }
                             }
                         }
}

function findAllcategories(){
    global $connection;

        $query = "SELECT * FROM categories";
                $query_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($query_result))
                                     {
                                         $cat_id = $row['cat_id'];
                                         $cat_title = $row['cat_title'];
                                    echo "<tr>";
                                    echo "<td>{$cat_id}</td>";
                                    echo "<td>{$cat_title}</td>";
                                    echo "<td><a href='categories.php?delete={$cat_id}'>DELETE</a></td>";
                                    echo "<td><a href='categories.php?update={$cat_id}'>UPDATE</a></td>";

                                    echo "</tr>";

                                     }
}

function deletecategories(){
    global $connection;
if (isset($_GET['delete']))
        {
        $the_cat_id = $_GET['delete'];
        $query_delete = "DELETE FROM categories WHERE ";
        $query_delete.= "cat_id = {$the_cat_id}";
            $query_delete_result = mysqli_query ($connection , $query_delete);
            header("Location:categories.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_delete_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }
}
?>