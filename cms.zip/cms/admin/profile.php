      <?php include "includes/admin_header.php"; ?>
    <div id="wrapper">

       
       
       
        <!-- Navigation -->
      <?php include "includes/admin_navigation.php"; ?>
       
      <?php
        
        if(isset($_SESSION['username']))
        {
            $username = $_SESSION['username'];
            
            $query = "SELECT * FROM users WHERE username = '$username' ";
             $query_result = mysqli_query ($connection,$query);       
            while ($row =mysqli_fetch_assoc($query_result))
                                     {
                                         $user_id = $row['user_id'];
                                         $user_username = $row['username'];
                                         $user_first_name = $row['user_firstname'];
                                         $user_last_name = $row['user_lastname'];                    
                                         $user_email = $row['user_email'];
                                         $user_role = $row['user_role'];                                   
                                         $user_image = $row['user_image'];
                                         $user_password = $row['user_password'];
                                     }
           
            
        }
        
        ?>
       
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                       <h1 class="page-header">
                              Welcome to Admin      
                              <small>Author</small>
                        </h1>
                        <?php
                        
            if(isset($_POST['edit_user'])){
                
                     $username = $_POST['username'];
                                         $user_firstname = $_POST['user_firstname'];
                                         $user_password  = $_POST['user_password'];
                                      /*   $user_image = $_FILES['image']['name'];
                                         $user_image_temp = $_FILES['image']['tmp_name'];
    */
                                         $user_lastname = $_POST['user_lastname'];
                                       //  $post_comment_counter = 4;
                                         $user_role = $_POST['user_role'];
                                         $user_email = $_POST['user_email'];
                
                
            $query_update = "UPDATE users SET ";
            $query_update.= "username = '$user_username', ";
            $query_update.= "user_firstname = '$user_firstname', ";
            $query_update.= "user_lastname = '$user_last_name', ";
            $query_update.= "user_password = '$user_password', "; 
            $query_update.= "user_role = '$user_role', ";
            $query_update.= "user_email = '$user_email' ";
            $query_update.= "WHERE username = '$username'";
               $query_update_result = mysqli_query ($connection,$query_update);

                
                if(!$query_update_result)
                {
                    die("Query failed" . mysqli_error($connection));
                }
                 
        }
                        
                        ?>
                                   
                                  <form action="" method="post" enctype="multipart/form-data">
    
    
    
    
        
                           <div class="form-group">
                             <label for="username">Username</label>
                             <input value="<?php echo $user_username; ?>" type="text" class="form-control" name="username">
                         </div>
                                                    <div class="form-group">

                         <select name="user_role" id="">
                         <option value="$user_role"><?php echo $user_role; ?></option>
                         <?php

                                     if ($user_role =='admin') { 
                                         echo "<option value='subscriber'>Subscriber</option>";

                                     }
                             
                             else {
                                         echo "<option value='admin'>admin</option>";

                             }
                             
    ?>
                         
                                                        </select>
                                      </div>
                         
                         
                         
                           <div class="form-group">
                             <label for="firstname">Firstrname</label>
                             <input value="<?php echo $user_first_name ?>"  type="text" class="form-control" name="user_firstname">
                         </div>
                         
                         
                           <div class="form-group">
                             <label for="user_status">Lastname</label>
                             <input   value="<?php echo $user_last_name ?>"  type="text" class="form-control" name="user_lastname">
                         </div>  
                            
                            
                            
                        
                         
                           <div class="form-group">
                             <label for="user_password">Password</label>
                             <input value="<?php echo $user_password ?>"  type="password" class="form-control" name="user_password">
                         </div>
                         
                         
                           <div class="form-group">
                             <label for="user_email">Email</label>
                             <input value="<?php echo $user_email ?>"  type="email" class="form-control" name="user_email">
                         </div>
                         
                          <div class="form-group">
                             
                             <input class="btn btn-primary" type="submit" name="edit_user" value="Update Profile">
                         </div>
  
                            </form>
                            
                           
                          
                             
                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
<?php include "includes/admin_footer.php"; ?>