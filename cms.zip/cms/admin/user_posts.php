<?php include "includes/admin_header.php"; ?>
    <div id="wrapper">

       
       
       
        <!-- Navigation -->
      <?php include "includes/admin_navigation.php"; ?>
       
      
       
        <div id="page-wrapper">

            <div class="container-fluid">
<?php
          if(isset($_GET['username']))             
          {
              $post_user = escape($_GET['username']);
          
                       
                        escape($_SESSION['username']) = $username; ?>
                        
         <?php

if(isset($_POST['checkBoxArray']))
{
     foreach($_POST['checkBoxArray'] as $checkBoxValue) 
     {
     $bulk_options = escape($_POST['bulk_options']);
         
         switch($bulk_options)
         {
                         case 'published' ;
                 $query_publish = "UPDATE posts SET post_status = '$bulk_options' WHERE post_id = $checkBoxValue";
                 $query_publish_result = mysqli_query ($connection,$query_publish);
                 
                 break;
                 
                   case 'draft' ;
                 $query_draft = "UPDATE posts SET post_status = '$bulk_options' WHERE post_id = $checkBoxValue";
                 $query_draft_result = mysqli_query ($connection,$query_draft);
                 
                 break;
                 
                   case 'delete' ;
               $query_delete_option = "DELETE FROM posts WHERE ";
               $query_delete_option.= "post_id = {$checkBoxValue}";
            $query_delete_option_result = mysqli_query ($connection , $query_delete_option);
                 break;
                 
                   case 'clone' ;
                 $query_clone = "SELECT * FROM posts WHERE post_id = $checkBoxValue";
                 
                  $query_clone_result = mysqli_query ($connection,$query_clone);
                                     while ($row =mysqli_fetch_assoc($query_clone_result))
                                     {
                                         $post_id = escape($row['post_id']);
                                         $post_author = escape($row['post_author']);
                                         $post_title = escape($row['post_title']);
                                         $post_category_id = escape($row['post_category_id']);
                                         $post_image = escape($row['post_image']);
                                         $post_tags = escape($row['post_tags']);
                                         $post_comment_counter = escape($row['post_comment_counter']);
                                         $post_status = escape($row['post_status']);
                                         $post_date = escape($row['post_date']);
                                       
                                     }
                
                       
$query_insert = "INSERT INTO posts(post_category_id,post_admin_user, post_title, post_author, post_date, post_image, post_tags, post_status)";
    
$query_insert.= " VALUES({$post_category_id},'{$username}','{$post_title}','{$post_author}',now(),'{$post_image}', '{$post_tags}','{$post_status}' ) ";

$query_result = mysqli_query ($connection , $query_insert);

if (!$query_clone_result)
{
    die("query failed" . mysqli_error($connection));
}     


                                    case 'reset' ;
                                
            $query_reset = "UPDATE posts SET post_views_count = 0 WHERE post_id = $checkBoxValue";
             $reset_result = mysqli_query ($connection,$query_reset);
                                             if(!$reset_result)
                                             {
                                             die("query failed" . mysqli_error($connection));
                                    }
     }
                                             }
}
                                         ?>



                       
                       
                       <form action="" method="post">
                        
                   <div id="bulkOptionContainer" class="col-xs-4">
                       
                       <select class="form-control" name="bulk_options" id="">
                             <option value="">Select Options</option>                          
                        
                           <option value="published">Publish</option>                          
                            <option value="draft">Draft</option>
                 <option value="delete">Delete</option>
                        <option value="clone">Clone</option>
                        <option value="reset">Reset Views</option>

                          
                       </select>
                       
                   </div> 
                       
                           <div class="col-xs-4">
               <input type="submit" name="submit" value="Apply" class="btn btn-success">
                <a href="posts.php?source=add_posts" class="btn btn-primary">Add New</a>           <a href="../author_posts.php?author=<?php echo $post_user; ?>" class="btn btn-primary">Show Posts</a>             

                               
                           </div>    
                        
                        <table class="table table-bordered table-hover">
                         <thead>
                             <tr>
        <th><input type="checkbox" id="SelectAllBoxes" ></th>
                                 <th>Id</th>
                                 <th>Author</th>
                                 <th>Title</th>
                                 <th>Category</th>
                                 <th>Status</th>
                                 <th>Image</th>
                                 <th>Tags</th>
                                 <th>Comments</th>                                                 <th>Date</th>
                                 <th>View Post</th>
                                 <th>Delete</th>
                                 <th>Edit</th>
                                 <th>Post Views</th>
                                 <th>Reset Views</th>
                             </tr>
                         </thead>
                         <?php
                           $query = "SELECT * FROM posts WHERE post_admin_user = '$post_user' ORDER BY post_id DESC";
                $query_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($query_result))
                                     {
                                         $post_id = escape($row['post_id']);
                                         $post_author = escape($row['post_author']);
                                         $post_title = escape($row['post_title']);
                                         $post_category_id = escape($row['post_category_id']);
                                         $post_image = escape($row['post_image']);
                                         $post_tags = escape($row['post_tags']);
                                         $post_comment_counter = escape($row['post_comment_counter']);
                                         $post_status = escape($row['post_status']);
                                         $post_date = escape($row['post_date']);
                                         $post_views_count = escape($row['post_views_count']);             $post_user =  escape($row['post_admin_user']);                 
  
                         ?>
                         <tbody>
                          
                             <tr>
                                <td><input type="checkbox" class="checkBoxes" name="checkBoxArray[]" value="<?php echo $post_id; ?>" ></td>
                                 <td><?php echo $post_id;?></td>
                                 <td><?php echo $post_user;?></td>
                                 <td><?php echo $post_title;?></td>
                                     <?php
                                      $query = "SELECT * FROM categories WHERE cat_id = $post_category_id ";
                $select_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($select_result))
                                     {
                                         $cat_id = escape($row['cat_id']);
                                         $cat_title = escape($row['cat_title']);
                                     
                                         ?>
             <td><?php echo $cat_title;  } ?></td>
             <td><?php echo $post_status;?></td>
             <td><?php echo "<img width='100'   img src='../images/$post_image' alt='image' "; ?></td>
             <td><?php echo $post_tags;?></td>

                                 <?php 
                               $query_count = "SELECT * FROM comments WHERE comment_post_id = $post_id ";
                               $query_count_result = mysqli_query ($connection,$query_count);
                                $counter = mysqli_num_rows($query_count_result);
                                 ?>
                                         
             <td><?php echo "<a href='post_comments.php?post_id=$post_id'>$counter<a/>";?></td>
             <td><?php echo $post_date;?></td>
             <td><?php echo "<a href='../post.php?p_id=$post_id'>View Post</a>"; ?></td>
             <td><?php echo "<a onClick=\"javascript: return confirm('Are you sure you want to delete'); \" href='posts.php?delete=$post_id'>DELETE</a> "; ?></td>
             <td><?php echo "<a href='posts.php?source=edit_posts&p_id=$post_id'>Edit</a> "; ?></td>
             <td><?php echo $post_views_count; ?></td>
             <td><a href="posts.php?reset&p_id=<?php echo $post_id; ?>">RESET</a></td>

                                 <?php 
                                      
                                         ?>

                             </tr>
                             <?php 
                                     }
                        
      
?>
                         </tbody>
                     </table>
                     </form>
                    
                   <?php
//$query_admin = "SELECT * FROM users WHERE user_role = 'admin' ";
//            $result = mysqli_query ($connection , $query_admin);
//              while ($row = mysqli_fetch_assoc($result))
//              {
//                  $user_role = $row['user_role'];
              if (isset($_SESSION['user_role']))
              {
       $user_role =  $_SESSION['user_role'];
                  if ($user_role =='admin')
                  {
if (isset($_GET['delete']))
        {
        $the_post_id = $_GET['delete'];
        $query_delete = "DELETE FROM posts WHERE ";
        $query_delete.= "post_id = {$the_post_id}";
            $query_delete_result = mysqli_query ($connection , $query_delete);
            header("Location:posts.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_delete_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }


   if(isset($_GET['reset']))
                                         {
                                              $the_post_id = $_GET['p_id'];
            $query_reset = "UPDATE posts SET post_views_count = 0 WHERE post_id = $the_post_id";
             $reset_result = mysqli_query ($connection,$query_reset);
                                             if(!$reset_result)
                                             {
                                             die("query failed" . mysqli_error($connection));
                                             }
                                         }
          }
              }
                }
?>
                  
                 
           </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
<?php include "includes/admin_footer.php"; ?>       
               
              
             
            