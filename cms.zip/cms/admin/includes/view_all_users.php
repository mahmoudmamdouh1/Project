
        <!-- Navigation -->
       
<?php 
if (isset($_GET['change_to_admin']))
        {
        $the_user_id = $_GET['change_to_admin'];
        $query_update = "UPDATE users SET ";
        $query_update.= "user_role = 'admin' WHERE user_id = $the_user_id";
            $query_update_result = mysqli_query ($connection , $query_update);
            header("Location:users.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_update_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }



if (isset($_GET['change_to_subscriber']))
        {
        $the_user_id = $_GET['change_to_subscriber'];
        $query_update = "UPDATE users SET ";
          $query_update.= "user_role = 'subscriber' WHERE user_id = $the_user_id";
            $query_update_result = mysqli_query ($connection , $query_update);
            header("Location:users.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_update_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }







if (isset($_GET['delete']))
        {
        $the_user_id = $_GET['delete'];
        $query_delete = "DELETE FROM users WHERE ";
        $query_delete.= "user_id = {$the_user_id}";
            $query_delete_result = mysqli_query ($connection , $query_delete);
            header("Location:users.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_delete_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }

?>
              <table class="table table-bordered table-hover">
                         <thead>
                             <tr>
                                 <th>Id</th>
                                 <th>username</th>     
                                 <th>Firstname</th>
                                 <th>Lastname</th>
                                 <th>Email</th>
                                 <th>Role</th>
                                 <th>View Admin Posts</th>
                                 <th>Admin</th>
                                 <th>Subscriber</th>
                                 <th>Edit</th>
                                 <th>Delete</th>
                             
                             </tr>
                         </thead>
                         <?php
                         
                           $query = "SELECT * FROM users";
                $query_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($query_result))
                                     {
                                         $user_id = $row['user_id'];
                                         $user_name = $row['username'];
                                         $user_first_name = $row['user_firstname'];
                                         $user_last_name = $row['user_lastname'];                    
                                         $user_email = $row['user_email'];
                                         $user_role = $row['user_role'];                                   
                                         $user_image = $row['user_image'];
                                         $user_password = $row['user_password'];
                                     
                         ?>
                         <tbody>
                          
                             <tr>
                                 <td><?php echo $user_id;?></td>
                                 <td><?php echo $user_name;?></td>                               
                                 <td><?php echo $user_first_name;?></td>
                                 <td><?php echo $user_last_name;?></td>
                                 <td><?php echo $user_email;?></td>
                                 <td><?php echo $user_role;?></td>
                                 
                                    
                                 <td><?php if($user_role =='admin') { echo "<a href='user_posts.php?username=$user_name'>View Posts</a> "; }
                                     else { echo "No Posts to show";
                                     } ?></td>
                                     
     <td><?php echo "<a href='users.php?change_to_admin=$user_id'>Admin</a> "; ?></td>
     <td><?php echo "<a href='users.php?change_to_subscriber=$user_id'>Subscriber</a> "; ?></td>
                  
                              
     <td><?php echo "<a href='users.php?source=edit_user&p_id=$user_id'>Edit</a> "; ?></td>
     <td><?php echo "<a href='users.php?delete=$user_id'>Delete</a> "; ?></td>

                             </tr>
                             <?php } ?>
                         </tbody>
                     </table>
                     
               
