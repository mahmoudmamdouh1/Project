
     <?php                             
 if(isset($_GET['p_id']))
                                     {
                                     $the_user_id = $_GET['p_id'];
                                     
                                     $query = "SELECT * FROM users WHERE user_id = $the_user_id ";
                $select_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($select_result))
                                     {
                                         $user_firstname = $row['user_firstname'];
                                         $user_username = $row['username'];
                                         $user_lastname = $row['user_lastname'];
                                         $user_password = $row['user_password'];
                                         $user_email = $row['user_email'];
                                         $user_image = $row['user_image'];
                                         $user_role = $row['user_role'];
                                      

                                     }
                             
if(isset($_POST['edit_user'])) {
    
    
                                   $user_firstname  =  $_POST['user_firstname'];
                                   $user_username  =  $_POST['username'];
                                   $user_lastname  =  $_POST['user_lastname'];
                                   $user_password  =  $_POST['user_password'];
                                   $user_email  =  $_POST['user_email'];
                                   $the_user_role  =  $_POST['user_role'];
   if(empty(trim($user_password)))
               {
                echo "Insert password";
               }



else    {
        
      $hashed_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 12));

                                   $query_update = "UPDATE users SET ";
                                   $query_update.= "user_firstname = '{$user_firstname}', ";
                                   $query_update.= "user_lastname = '{$user_lastname}', ";
                                   $query_update.= "username = '{$user_username}', ";
                                   $query_update.= "user_password = '{$hashed_password}', ";
                                   $query_update.= "user_email = '{$user_email}', ";
                                   $query_update.= "user_role = '{$the_user_role}' ";

                                   $query_update.= "WHERE user_id = {$the_user_id} ";
                                   $query_update_result = mysqli_query ($connection ,$query_update);
                                        if (!$query_update_result)
                                            {
                                            die ("QUERY failed" . mysqli_error($connection));
                                            }
                                   } 

}                ?>
                                     
                                    
                                   
                                  <form action="" method="post" enctype="multipart/form-data">
    
    
                           <div class="form-group">
                             <label for="username">Username</label>
                             <input value="<?php echo $user_username; ?>" type="text" class="form-control" name="username">
                         </div>
                                                    <div class="form-group">

                         <select name="user_role" id="">
                         <option value="<?php echo $user_role; ?>"><?php echo $user_role; ?></option>
                         <?php

                                     if ($user_role =='admin') { 
                                         echo "<option value='subscriber'>Subscriber</option>";

                                     }
                             
                             else {
                                         echo "<option value='admin'>Admin</option>";

                             }
                             
    ?>
                         
                                                        </select>
                                      </div>
                         
                         
                         
                           <div class="form-group">
                             <label for="firstname">Firstrname</label>
                             <input value="<?php echo $user_firstname ?>"  type="text" class="form-control" name="user_firstname">
                         </div>
                         
                         
                           <div class="form-group">
                             <label for="user_status">Lastname</label>
                             <input   value="<?php echo $user_lastname ?>"  type="text" class="form-control" name="user_lastname">
                         </div>  
                            
                            
                            
                        
                         
                           <div class="form-group">
                             <label for="user_password">Password</label>
                             <input value="<?php echo $user_password ?>"  type="password" class="form-control" name="user_password">
                         </div>
                         
                         
                           <div class="form-group">
                             <label for="user_email">Email</label>
                             <input value="<?php echo $user_email ?>"  type="email" class="form-control" name="user_email">
                         </div>
                         
                          <div class="form-group">
                             
                             <input class="btn btn-primary" type="submit" name="edit_user" value="Update user">
                         </div>
  
                            </form>
                            
                           <?php 
        
 }
 
                else {
                    header("Location:..");
                }
                