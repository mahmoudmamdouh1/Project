
                            
                              <form action="" method="post">
                         <div class="form-group">
                              <label for="cat-title">edit Category</label>
                              
                     <?php      
                                     if(isset($_GET['update']))
                                     {
                                     $cat_id = $_GET['update'];
                                     $query = "SELECT * FROM categories WHERE cat_id = $cat_id ";
                $select_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($select_result))
                                     {
                                         $cat_id = $row['cat_id'];
                                         $cat_title = $row['cat_title'];
        ?>
                        
                             <input value="<?php if(isset($cat_title)) {echo $cat_title;} ?>" type="text" class="form-control" name="cat_title">
                            
                         
                             <?php } } ?>
                             
                     
                      <?php  
                                   if(isset($_POST['update']))  
                                   {
                                   $the_cat_title  =  $_POST['cat_title'];
                                   $query_update = "UPDATE categories SET ";
                                   $query_update.= "cat_title = '{$the_cat_title}' ";
                                   $query_update.= "WHERE cat_id = {$cat_id} ";
                                   $query_update_result = mysqli_query ($connection ,$query_update);
                                        if (!$query_update_result)
                                            {
                                            die ("QUERY failed" . mysqli_error($connection));
                                            }
                                   } 
                                     ?>   

                         
                           <div class="form-group">
                             
                             <input class="btn btn-primary" type="submit" name="update" value="update Category">
                         </div>
                         </div>
                          
                     </form>
                           
                            

                    
                   
                   