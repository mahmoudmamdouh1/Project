
     <?php                             
 if(isset($_GET['p_id']))
                                     {
                                     $post_id = $_GET['p_id'];
                                     
                                     $query = "SELECT * FROM posts WHERE post_id = $post_id ";
                $select_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($select_result))
                                     {
                                         $post_id = $row['post_id'];
                                         $post_title = $row['post_title'];
                                         $post_admin = $row['post_admin_user'];
                                         $post_status = $row['post_status'];
                                         $post_content = $row['post_content'];
                                         $post_tags = $row['post_tags'];
                                         $post_image = $row['post_image'];
                                         $post_comment_count = $row['post_comment_counter'];
                                         $post_date = $row['post_date'];
                                         $post_category_id = $row['post_category_id'];

                                     }
                           
if(isset($_POST['edit_post'])) {
    
                                   $user_admin = escape($_POST['user_admin']);

                                   $the_post_title  =  escape($_POST['post_title']);
                                   $the_post_tags  =  escape($_POST['post_tags']);
                                   $the_post_content  =  escape ($_POST['post_content']);
                                   $the_post_status  = escape($_POST['post_status']);
                                   $the_post_category = escape($_POST['post_category']);
                                   $post_image  =  escape($_FILES['image']['name']);
                                   $post_image_temp  =  escape($_FILES['image']['tmp_name']);
move_uploaded_file($post_image_temp,"../images/$post_image");

    if(empty($post_image))
    {
    $query = "SELECT * from posts WHERE post_id = $post_id";
        
        $query_image = mysqli_query ($connection ,$query);
                                        if (!$query_image)
                                            {
                                            die ("QUERY failed" . mysqli_error($connection));
                                            }
                                    
     while ($row =mysqli_fetch_assoc($query_image))
                                     {
                                       
                                         $post_image = escape($row['post_image']);
                                       
                                     }
                                         
    }
     
    
                                   $query_update = "UPDATE posts SET ";
    
                                   $query_update.= "post_date = now(), ";
                                   $query_update.= "post_admin_user = '{$user_admin}', ";

                                   $query_update.= "post_title = '{$the_post_title}', ";
                                   $query_update.= "post_category_id = '{$the_post_category}', ";
                                   $query_update.= "post_status = '{$the_post_status}', ";
                                   $query_update.= "post_content = '{$the_post_content}', ";
                                   $query_update.= "post_tags = '{$the_post_tags}', ";
                                   $query_update.= "post_image = '{$post_image}' ";

                                   $query_update.= "WHERE post_id = {$post_id} ";
                                   $query_update_result = mysqli_query ($connection ,$query_update);
                                        if (!$query_update_result)
                                            {
                                            die ("QUERY failed" . mysqli_error($connection));
                                            }
        echo "<p class='bg-success'>Post has been updated" . " " . "<a href='../post.php?p_id=$post_id'>View Post</a>" . " OR  " . "<a href='posts.php'>Edit More Posts</a> </p>";

                                   } 


                                     ?>
                                     
                                    
                                   
                                  <form action="" method="post" enctype="multipart/form-data">
    
    
    
                                    <div class="form-group">

     <select name="user_admin" id="">
                         <?php
$query_select_user = "SELECT username FROM users WHERE user_role ='admin' ";
     
  $query_update_result = mysqli_query ($connection ,$query_select_user);
     
                                        if (!$query_update_result)
                                            {
                                            die ("QUERY failed" . mysqli_error($connection));
                                            } 
     while ($row=mysqli_fetch_assoc($query_update_result))
     {        
         $the_user_id = escape($row['user_id']);

         $the_user_admin = escape($row['username']);
         escape(
             echo "<option value='$the_user_admin'>$the_user_admin </option>";
// lma 7tet gwa value $the_user_id mkan4 byzhr el 2sm 
                                     
     }
                             
                             
                             
    ?>
                         
                                                        </select>
                                      </div>
                         
        
    
        
                           <div class="form-group">
                             <label for="title">Post Title</label>
                             <input value="<?php echo $post_title; ?>" type="text" class="form-control" name="post_title">
                         </div>
                                                    <div class="form-group">

                         <select name="post_category" id="">
                         
                         <?php
    
     $query = "SELECT * FROM categories";
                $select_result = mysqli_query ($connection,$query);
                                     while ($row =mysqli_fetch_assoc($select_result))
                                     {
                                         $cat_id = escape($row['cat_id']);
                                         $cat_title = escape($row['cat_title']);
    
                                         
                                         echo "<option value='$cat_id'>$cat_title</option>";

                                     }
    ?>
                         
                                                        </select>
                                      </div>
                         
                          
                         
                             
                         
                         
                          <div class="form-group">

                         <select name="post_status" id="">
                         
                         <?php
    
     $query = "SELECT * FROM posts";
                              
                                         echo "<option value='$post_status'>$post_status</option>";

                                     if($post_status =='published')
                                     {
                               echo "<option value='draft'>Draft</option>";
                                     }
                                    else {
                               echo "<option value='published'>Published</option>";
                                    }
    ?>
                         
                                                        </select>
                                      </div>
                         
                         
                            
                            
                            <div class="form-group">
                          <img width="100" src="../images/<?php echo $post_image; ?>" alt="">
                          <input type="file" name="image">
                         </div>
                         
                           <div class="form-group">
                             <label for="post_tags">Post Tags</label>
                             <input value="<?php echo $post_tags ?>"  type="text" class="form-control" name="post_tags">
                         </div>
                         
                          <div class="form-group">
                     <label for="post_content">Post Content</label>
                     <textarea value="<?php echo $post_content ?>"  class="form-control" name="post_content" id="" cols="30" $_POSTs="10">
                              </textarea> </div>
                         
                         
                          <div class="form-group">
                             
                             <input class="btn btn-primary" type="submit" name="edit_post" value="Update Post">
                         </div>
  
                            </form>
                            
                           
                          
                         <?php
        
 }
 
                else {
                    header("Location:..");
                }
                