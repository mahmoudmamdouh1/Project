
   <?php

if(isset($_POST['create_user']))
{

                                         $username = $_POST['username'];
                                         $user_firstname = $_POST['user_firstname'];
                                         $user_password  = $_POST['user_password'];
                                      /*   $user_image = $_FILES['image']['name'];
                                         $user_image_temp = $_FILES['image']['tmp_name'];
    */
                                         $user_lastname = $_POST['user_lastname'];
                                       //  $post_comment_counter = 4;
                                         $user_role = $_POST['user_role'];
                                         $user_email = $_POST['user_email'];
 //move_uploaded_file($post_image_temp,"../images/$post_image");
    
    $user_password = password_hash($user_password, PASSWORD_BCRYPT , array ('cost' =>12));

$query_insert = "INSERT INTO users(username, user_password, user_firstname, user_lastname, user_role, user_email)";
    
$query_insert.= " VALUES('{$username}','{$user_password}','{$user_firstname}','{$user_lastname}', '{$user_role}','{$user_email}') ";

$query_result = mysqli_query ($connection , $query_insert);

if (!$query_result)
{
    die("query failed" . mysqli_error($connection));
}
echo "User Created :" . "<a href='users.php'>View Users</a>";

}


?>

   
   
   <form action="" method="post" enctype="multipart/form-data">
    
       
                           <div class="form-group">
                             <label for="title">Firstname</label>
                             <input type="text" class="form-control" name="user_firstname">
                         </div>
                         
                         
                           <div class="form-group">
                             <label for="post_status">Lastname</label>
                             <input type="text" class="form-control" name="user_lastname">
                         </div>  
                            
    
    
        
                          
                         
                         <div class="form-group">

                         <select name="user_role" id="">
                         
                        <option value="subscriber">Select option</option>    
                                     <option value="admin">Admin</option>    
                                     <option value="subscriber">Subscriber</option>   
                                                    </select>
                                      </div>
                         
                          
                         
                      
                            
                 <!--           
                            <div class="form-group">
                             <label for="post_image">Post Image</label>
                             <input type="file" name="image">
                         </div>
                         
                         -->
                         
                           <div class="form-group">
                             <label for="post_tags">Username</label>
                             <input type="text" class="form-control" name="username">
                         </div>
                         
                         <div class="form-group">
                             <label for="post_tags">Email</label>
                             <input type="text" class="form-control" name="user_email">
                         </div>
                         
                           <div class="form-group">
                             <label for="post_tags">Password</label>
                             <input type="text" class="form-control" name="user_password">
                         </div>
                         
                          <div class="form-group">
                             
                             <input class="btn btn-primary" type="submit" name="create_user" value="Add User">
                         </div>
  
                            </form>