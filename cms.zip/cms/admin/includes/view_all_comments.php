
        <!-- Navigation -->
       
<?php 
if (isset($_GET['approve']))
        {
        $the_comment_id = $_GET['approve'];
        $query_update = "UPDATE comments SET ";
        $query_update.= "comment_status = 'approved' WHERE comment_id = $the_comment_id";
            $query_update_result = mysqli_query ($connection , $query_update);
            header("Location:comments.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_update_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }



if (isset($_GET['unapprove']))
        {
        $the_comment_id = $_GET['unapprove'];
        $query_update = "UPDATE comments SET ";
        $query_update.= "comment_status = 'unapproved' WHERE comment_id = $the_comment_id";
            $query_update_result = mysqli_query ($connection , $query_update);
            header("Location:comments.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_update_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }







if (isset($_GET['delete']))
        {
        $the_comment_id = $_GET['delete'];
        $query_delete = "DELETE FROM comments WHERE ";
        $query_delete.= "comment_id = {$the_comment_id}";
            $query_delete_result = mysqli_query ($connection , $query_delete);
            header("Location:comments.php");  
            // important to redirect to the main page not with id = 20 : refresh
            if (!$query_delete_result)
            {
                die ("QUERY failed" . mysqli_error($connection));
            }
        }



 

?>
                  
    
                     
                       <table class="table table-bordered table-hover">
                         <thead>
                             <tr>
                                 <th>Id</th>
                                 <th>Post Id</th>     
                                 <th>Author</th>
                                 <th>Comment</th>
                                 <th>Email</th>
                                 <th>Status</th>
                                 <th>In Response To</th>
                                 <th>Date</th>
                                 <th>Approve</th>
                                 <th>UnApprove</th>                                                       <th>Edit</th>
                                 <th>Delete</th>
                             </tr>
                         </thead>
                         <?php
                         
                           $query_comments = "SELECT * FROM comments";
                $query_result = mysqli_query ($connection,$query_comments);
                                     while ($row =mysqli_fetch_assoc($query_result))
                                     {
                                         $comment_id = $row['comment_id'];
                                         $comment_author = $row['comment_author'];
                                         $comment_post_id = $row['comment_post_id'];
                                         $comment_status = $row['comment_status'];                    
                                         $comment_email = $row['comment_email'];
                                         $comment_content = $row['comment_content'];
                                         $comment_date = $row['comment_date'];
                                     
                         ?>
                         <tbody>
                          
                             <tr>
                                 <td><?php echo $comment_id;?></td>
                                   <td><?php echo $comment_post_id;?></td>
                                   
                                 <td><?php echo "$comment_author";?></td>
                                 
                                 
                                 <td><?php echo $comment_content;?></td>
    
                                 <td><?php echo $comment_email;?></td>
                                 <td><?php echo $comment_status;?></td>
                                 
                                 
                                 <?php
                                        
                                     $query_post = "SELECT * FROM posts WHERE post_id = $comment_post_id";
                $query_post_select = mysqli_query ($connection,$query_post);
                                     while ($row =mysqli_fetch_assoc($query_post_select))
                                     {
                                         $post_id = $row['post_id'];
                                         $post_title = $row['post_title'];
                                       
                                 
                          echo   "<td><a href='../post.php?p_id=$comment_post_id'>$post_title</td>";
                                     
                                 ?>
                                 <td><?php echo $comment_date;?></td>
                                 <td><?php echo "<a href='comments.php?approve=$comment_id'>Approve</a> "; ?></td>
     <td><?php echo "<a href='comments.php?unapprove=$comment_id'>Unapprove</a> "; ?></td>

     <td><?php echo "<a href='comments.php?source=edit_comment&p_id=$comment_id'>Edit</a> "; ?></td>
                                 <td><?php echo "<a href='comments.php?delete=$comment_id'>Delete</a> "; ?></td>
                             </tr>
                             <?php }} ?>
                         </tbody>
                     </table>
                     
               
