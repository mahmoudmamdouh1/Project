         

 <?php

$_SESSION['subject'] = null;
$_SESSION['user_role'] = null;
$_SESSION['user_body'] = null;
$_SESSION['user_email'] = null;


?>
    


<?php  include "includes/db.php"; ?>
 <?php  include "includes/header.php"; ?>



    <!-- Navigation -->
    
    <?php  include "includes/navigation.php"; ?>
   
    <?php


if(isset($_POST['submit']))

{
    
    $subject = $_POST['subject'];  
    $body = $_POST['body'];    
    $email    = $_POST['email'];

                        
   $subject = mysqli_real_escape_string($connection, $subject);
   $body = mysqli_real_escape_string($connection, $body);
   $email = mysqli_real_escape_string($connection, $email);


//    $query_randSalt = "SELECT rand_salt FROM users";
//      $query_randSalt_result = mysqli_query ($connection,$query_randSalt);
//
//    if(!$query_randSalt_result)
//         {
//            die("query failed" . mysqli_error($connection));
//        }
//     $row = mysqli_fetch_assoc($query_randSalt_result);
//                                     
//                                         $rand_salt = $row['rand_salt'];
//     $body = crypt($body , $rand_salt);
//  
    
     
    
     if (empty(trim($subject))) {
    $message = "subject should not be empty";
    } 
   
 elseif (empty(trim($body))) {
       $message = "body should not be empty";
    } 
    
     elseif(empty(trim($email))) {
        echo "email should not be empty";
    } 
    
else 
    {
        $query_insert = "INSERT INTO users(subject , user_firstname ,user_email , user_body) ";
        $query_insert.= "VALUES ('$subject' ,'$email','$body')";
        $query_insert_result = mysqli_query ($connection,$query_insert);
        if(!$query_insert_result)
        {
            die("query failed" . mysqli_error($connection));
        }
    $message = "Registration completed ";
    }
   
}


?>
    
    
    
    
    
    
 
    <!-- Page Content -->
    <div class="container">
    
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Register</h1>
                    <form role="form" action="registration.php" method="post" id="login-form" autocomplete="off">
                      <h6 class="text-center"><?php if(isset($_POST['submit'])){
                          echo $message; } ?></h6>
                        <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="somebody@example.com">
                        </div>
                         <div class="form-group">
                            <label for="subject" class="sr-only">Subject</label>
                            <input type="subject" name="subject" id="subject" class="form-control" placeholder="Enter your subject">
                        </div>
                         <div class="form-group">
                            <textarea name="body" class="form-control" id="body" cols="50" rows="10">
                             </textarea>
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Submit">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


        <hr>



<?php include "includes/footer.php";?>
