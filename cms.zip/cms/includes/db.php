<?php 

$connection = mysqli_connect ('localhost','root','','cms');


if (!$connection)
{
echo "we are not connected"; 
}


?>