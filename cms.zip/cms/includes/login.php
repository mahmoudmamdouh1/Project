
<?php include "db.php"; ?>
<?php session_start(); ?>

<?php

      


if(isset($_POST['login']))

{
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    $username = mysqli_real_escape_string ($connection , $username);
    $password = mysqli_real_escape_string ($connection , $password);

      $query = "SELECT * FROM users WHERE username = '$username' ";
                $query_result = mysqli_query ($connection,$query);
                    if(!$query_result)
                    {
                        die("Query failed" . mysqli_error($connection));
                    }
    
                                     while ($row =mysqli_fetch_array($query_result))
                                     {
                                         $user_id = $row['user_id'];
                                         $user_name = $row['username'];
                                         $user_first_name = $row['user_firstname'];
                                         $user_last_name = $row['user_lastname'];                    
                                         $user_role = $row['user_role'];                                   
                                         $user_password = $row['user_password'];
                                     
                                     }
     //    $password = crypt($password , $user_password);


if (empty($username) || empty($password))
    {
        header("Location:../index.php");
        echo "Wrong username or password";
    }
    
    //elseif($username == $user_name && $password == $user_password)
        elseif(password_verify($password,$user_password))
    {
        $_SESSION['username'] = $user_name;
        $_SESSION['user_firstname'] = $user_first_name;
        $_SESSION['user_lastname'] = $user_last_name;
        $_SESSION['user_role'] = $user_role;
              header("Location:../admin");  

        
    }
    
    
    
    
    else {
        
                header("Location:../index.php");

    }
    
           

    
    
}




?>